public class Understand {
	public static void main(String[] args) {
		int[][] cBoard = new int[][] {
			{1, 0, 0, 0},
			{0, 0, 0, 0},
			{0, 0, 4, 0},
			{0, 0, 0, 0}
		};
		for (int a = 0; a < 4; a++) {
			System.out.println();
			for (int b = 0; b < 4; b++) {
				System.out.print(cBoard[a][b] + " ");
			}
		}

		tiltBoard("SOUTH", cBoard);
		System.out.println("AFTER TRANSFORMATION");

		for (int a = 0; a < 4; a++) {
			System.out.println();
			for (int b = 0; b < 4; b++) {
				System.out.print(cBoard[a][b] + " ");
			}
		}

		int a = 0;
		for (int b = 0; b < 10; b++) {
			if (b < 3) {
				a++;
			} else {
				break;
			}
		}
		System.out.println();
		System.out.println(a);
      
	}

	public static void tiltBoard(String side, int[][] b) {
        /* As a suggestion (see the project text), you might try copying
         * the board to a local array, turning it so that edge SIDE faces
         * north.  That way, you can re-use the same logic for all
         * directions.  (As usual, you don't have to). */
        int[][] board = new int[4][4];
        // FIXME?

        
        for (int r = 0; r < 4; r += 1) {
            for (int c = 0; c < 4; c += 1) {
                board[r][c] =
                    b[tiltRow(side, r, c)][tiltCol(side, r, c)];
                // FIXME?
            }
        }        

        // FIXME?

        for (int a = 0; a < 4; a++) {
        	for (int d = 0; d < 4; d++) {
        		b[a][d] = board[a][d];
        	}
        }

        /*for (int r = 0; r < 4; r += 1) {
            for (int c = 0; c < 4; c += 1) {
                b[tiltRow(side, r, c)][tiltCol(side, r, c)]
                    = board[r][c];
            }
        }*/
        /** FIXME?
         *
         *  May or may not be using the information above.
         *  Will use this to try and figure out when it should return true or false,
         *  and go from there after figuring out when it returns true or false */


        
    }

    /** Return the row number on a playing board that corresponds to row R
     *  and column C of a board turned so that row 0 is in direction SIDE (as
     *  specified by the definitions of NORTH, EAST, etc.).  So, if SIDE
     *  is NORTH, then tiltRow simply returns R (since in that case, the
     *  board is not turned).  If SIDE is WEST, then column 0 of the tilted
     *  board corresponds to row SIZE - 1 of the untilted board, and
     *  tiltRow returns SIZE - 1 - C. */
    public static int tiltRow(String side, int r, int c) {
        switch (side) {
        case "NORTH":
            return r;
        case "EAST":
            return c;
        case "SOUTH":
            return 4 - 1 - r;
        case "WEST":
            return 4 - 1 - c;
        default:
            throw new IllegalArgumentException("Unknown direction");
        }
    }

    /** Return the column number on a playing board that corresponds to row
     *  R and column C of a board turned so that row 0 is in direction SIDE
     *  (as specified by the definitions of NORTH, EAST, etc.). So, if SIDE
     *  is NORTH, then tiltCol simply returns C (since in that case, the
     *  board is not turned).  If SIDE is WEST, then row 0 of the tilted
     *  board corresponds to column 0 of the untilted board, and tiltCol
     *  returns R. */
    public static int tiltCol(String side, int r, int c) {
        switch (side) {
        case "NORTH":
            return c;
        case "EAST":
            return 4 - 1 - r;
        case "SOUTH":
            return 4 - 1 - c;
        case "WEST":
            return r;
        default:
            throw new IllegalArgumentException("Unknown direction");
        }
    }
    
}
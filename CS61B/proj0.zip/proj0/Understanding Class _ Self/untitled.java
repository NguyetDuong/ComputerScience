public Class Understand {
	public static void main(String[] args) {
		int[][] something = new int[4][4];
		System.out.println(something[0][2]);
		System.out.println(something[0][2] == 0); 	
	}
}